How to install theme on Pterodactyl?
1. Open "files" folder.
2. Copy all and go paste Pterodactyl main folder.


How to activate the theme?
1. Open ".env" file with editor.
2. Find "APP_THEME=pterodactyl" and change this > "APP_THEME=kunefe"